﻿using System;
namespace Cai2023Datos.Utilidades
{
    public class TransactionResult
    {

        public bool IsOk { get; set; }
        public int Id { get; set; }
        public string Error { get; set; }
    
    }
}

