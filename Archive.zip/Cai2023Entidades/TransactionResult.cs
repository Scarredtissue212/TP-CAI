﻿using System;
namespace Cai2023Entidades
{
    public class TransactionResult
    {
        public bool IsOk { get; set; }
        public int Id { get; set; }
    }
}

