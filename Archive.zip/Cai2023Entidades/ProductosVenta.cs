﻿using System;
namespace Cai2023Entidades
{
    public class ProductosVenta
    {
        String idCliente;
        String idUsuario;
        List<ItemProductosVentas> listadoProductosVentas;

        public ProductosVenta()
        {
        }

        public string IdCliente { get => idCliente; set => idCliente = value; }
        public string IdUsuario { get => idUsuario; set => idUsuario = value; }
        public List<ItemProductosVentas> ListadoProductosVentas { get => listadoProductosVentas; set => listadoProductosVentas = value; }
    }
}

