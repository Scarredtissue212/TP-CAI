﻿using System;
namespace Cai2023Datos
{
	public class BaseDatos
    {
        protected Guid idUsuario = Guid.Parse("D347CE99-DB8D-4542-AA97-FC9F3CCE6969");
        protected int host = 1;
        protected string nombre = "juan";
        protected string apellido = "pablo";
        protected int dni = 40673261;
        protected string direccion = "AvFalsa 123";
        protected int telefono = 11111111;
        protected string email = "juan@gmail.com";
        protected DateTime fechanacimiento = DateTime.Parse("2000-11-05T18:44:05.089Z");
        protected string nombreusuario = "jprociuk";
        protected string contrasena = "Cai20232";
    }
}

