﻿using System;
using Cai2023Entidades;
using Cai2023Datos;


namespace Cai2023Negocio
{
    public class ReporteNegocio
    {
        private readonly VentaDatos ventaDatos;
        /*
        public List<Venta> ReporteVentasPorCategoria()
        {
            List<Venta> ventas = ventaDatos.TraerTodos();
            List<Venta> reporteVentasporCat = ventas.FindAll(v => v.Id == v.Id);
            return reporteVentasporCat;
        }

        public void ReporteVentasPorVendedor()
        {
            List<Venta> ventas = ventaDatos.TraerTodos();
            List<Venta> reporteVentasporVendedor = ventas.FindAll(v => v.Id == v.IdUsuario);
            Console.WriteLine(reporteVentasporVendedor);
        }

        // Reporte stock critico
        //      Productos con un stock menor al 25% organizado por categoría
        //      Para los perfiles Supervisor y Administrador deberá aparecer un mensaje
        //      en el menú principal con la leyenda “Hay x productos con stock crítico!!!”

        */
    }
}
